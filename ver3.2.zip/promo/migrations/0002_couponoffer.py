import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('cafes', '0003_menucategory_slug'),
        ('promo', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='CouponOffer',
            fields=[
                (
                    'id',
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name='ID',
                    ),
                ),
                ('title', models.CharField(max_length=120, verbose_name='Название')),
                ('description', models.TextField(blank=True, verbose_name='Описание')),
                (
                    'cost_points10',
                    models.PositiveIntegerField(default=100, verbose_name='Цена (баллы x10)'),
                ),
                (
                    'expires_in_days',
                    models.PositiveIntegerField(
                        blank=True,
                        help_text='Если пусто — купон будет без срока',
                        null=True,
                        verbose_name='Срок после покупки (дни)',
                    ),
                ),
                (
                    'is_active',
                    models.BooleanField(default=True, verbose_name='В продаже'),
                ),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                (
                    'cafe',
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name='coupon_offers',
                        to='cafes.cafe',
                        verbose_name='Кафе (если привязан)',
                    ),
                ),
            ],
            options={
                'verbose_name': 'Купон (магазин)',
                'verbose_name_plural': 'Купоны (магазин)',
                'ordering': ['-created_at'],
            },
        ),
    ]
