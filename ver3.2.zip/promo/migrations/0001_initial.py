import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        ('add_order', '0003_order_points_accrued'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='PointsTransaction',
            fields=[
                (
                    'id',
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name='ID',
                    ),
                ),
                ('amount10', models.IntegerField()),
                (
                    'kind',
                    models.CharField(
                        choices=[
                            ('ACCRUAL', 'Начисление'),
                            ('ADJUST', 'Корректировка'),
                            ('SPEND', 'Списание'),
                        ],
                        default='ACCRUAL',
                        max_length=20,
                    ),
                ),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                (
                    'order',
                    models.ForeignKey(
                        blank=True,
                        null=True,
                        on_delete=django.db.models.deletion.SET_NULL,
                        related_name='points_transactions',
                        to='add_order.order',
                    ),
                ),
                (
                    'user',
                    models.ForeignKey(
                        on_delete=django.db.models.deletion.CASCADE,
                        related_name='points_transactions',
                        to=settings.AUTH_USER_MODEL,
                    ),
                ),
            ],
            options={
                'ordering': ['-created_at'],
                'indexes': [
                    models.Index(
                        fields=['user', '-created_at'],
                        name='promo_point_user_id_8430b0_idx',
                    ),
                    models.Index(
                        fields=['user', 'kind', '-created_at'],
                        name='promo_point_user_id_ef57a0_idx',
                    ),
                ],
            },
        ),
    ]
