from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from django.views.generic import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('feed.urls')),
    path('', include('user_registration.urls')),
    path('profile/', include('user_profile.urls')),
    path('add/', include('add_order.urls')),
    path('cafes/', include('cafes.urls')),
    path('friends/', include('friends.urls')),
    path('promo/', include('promo.urls')),
    path('drops/', include('drops.urls')),
    path('trade/', include('trades.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


urlpatterns += [
    path('favicon.ico', RedirectView.as_view(url='/static/favicon/favicon.ico')),
]
