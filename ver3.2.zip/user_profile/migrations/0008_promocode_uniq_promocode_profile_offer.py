from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('promo', '0002_couponoffer'),
        ('user_profile', '0007_promocode_source_offer'),
    ]

    operations = [
        migrations.AddConstraint(
            model_name='promocode',
            constraint=models.UniqueConstraint(
                condition=models.Q(('source_offer__isnull', False)),
                fields=('profile', 'source_offer'),
                name='uniq_promocode_profile_offer',
            ),
        ),
    ]
