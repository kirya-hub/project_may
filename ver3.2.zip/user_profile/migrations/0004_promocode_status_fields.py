from django.db import migrations, models
from django.utils import timezone


def fill_status_from_is_active(apps, schema_editor):
    PromoCode = apps.get_model('user_profile', 'PromoCode')
    today = timezone.localdate()

    for p in PromoCode.objects.all():
        # если уже истёк по дате — считаем EXPIRED
        if p.expires_at and p.expires_at < today:
            p.status = 'EXPIRED'
        else:
            # иначе по старому флагу
            p.status = 'ACTIVE' if p.is_active else 'USED'
        p.save(update_fields=['status'])


class Migration(migrations.Migration):
    dependencies = [
        ('user_profile', '0003_profile_points10'),
    ]

    operations = [
        migrations.AddField(
            model_name='promocode',
            name='acquired_at',
            field=models.DateTimeField(default=timezone.now, verbose_name='Получен'),
        ),
        migrations.AddField(
            model_name='promocode',
            name='status',
            field=models.CharField(
                choices=[
                    ('ACTIVE', 'Активен'),
                    ('USED', 'Использован'),
                    ('EXPIRED', 'Истёк'),
                ],
                default='ACTIVE',
                max_length=10,
                verbose_name='Статус',
            ),
        ),
        migrations.AddField(
            model_name='promocode',
            name='used_at',
            field=models.DateTimeField(blank=True, null=True, verbose_name='Использован'),
        ),
        migrations.RunPython(fill_status_from_is_active, migrations.RunPython.noop),
    ]
