import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('promo', '0002_couponoffer'),
        ('user_profile', '0006_alter_promocode_options'),
    ]

    operations = [
        migrations.AddField(
            model_name='promocode',
            name='source_offer',
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='issued_promocodes',
                to='promo.couponoffer',
                verbose_name='Купон из магазина',
            ),
        ),
    ]
