from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('user_profile', '0002_remove_profile_friends_profile_name'),
    ]

    operations = [
        migrations.AddField(
            model_name='profile',
            name='points10',
            field=models.PositiveIntegerField(default=0, verbose_name='Баланс (x10)'),
        ),
    ]
